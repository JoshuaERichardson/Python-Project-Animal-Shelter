from django.contrib import admin

from .models import Pets
admin.site.register(Pets)